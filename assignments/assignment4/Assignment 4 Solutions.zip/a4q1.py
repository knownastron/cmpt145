# CMPT 145.201801 Assignment 4 Question 1
# Working with stacks

import sys as sys
import TStack as Stack
import TQueue as Queue

def print_case_order_this_month(line):
    """
    Purpose:
        Print the words in line to the console in reverse order
    Precondition:
        line: a string
    Post-condition:
        Displays a line of words to the console
    Returns:
        None
    """

    urgent_cases_stack = Stack.create()
    regular_cases_queue = Queue.create()

    case_queue = Queue.create()
    for case in line.split():
        Queue.enqueue(case_queue, case)

    while not Queue.is_empty(case_queue):
        cur_case = Queue.dequeue(case_queue)
        if cur_case.startswith("URG"):
            # This is an urgent case. Put it on our urgent stack
            Stack.push(urgent_cases_stack, cur_case)
        else:
            Queue.enqueue(regular_cases_queue, cur_case)

    # Print out all urgent cases
    while not Stack.is_empty(urgent_cases_stack):
        print(Stack.pop(urgent_cases_stack), end=' ')  # no newline
    # Print out all non-urgent case, remember to have them all be on the same line!
    while not Queue.is_empty(regular_cases_queue):
        print(Queue.dequeue(regular_cases_queue), end=' ')
    print() # newline at the end


if len(sys.argv) != 2:
    # give help when called improperly
    print('usage:', sys.argv[0], '<filename>')
else:
    infile = open(sys.argv[1])

    # Enqueue all lines (and strip out any spaces
    lines = Queue.create()
    for line in infile:
        line = line.rstrip()
        Queue.enqueue(lines, line)
    infile.close()

    # print the lines in reverse
    month_num = 1
    while not Queue.is_empty(lines):
        line = Queue.dequeue(lines)
        # print each line in reverse order
        print("Month", str(month_num) + ":",end=' ')
        print_case_order_this_month(line)
        month_num += 1

