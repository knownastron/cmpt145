
def create (data , next = None ):
	"""
	Create a new node for the given data .
	Pre - conditions : data : Any data value to be stored in the node; next : Another node (or None , by default )
	Post - condition : none
	Return : the node created
	"""
	return {'data':data ,'next': next }

def get_data ( node ):
	"""
	Retrieve the contents of the data field .
	Pre - conditions : node : a node created by create ()
	Post - conditions : none
	Return the data value stored previously in the node
	"""
	return node ['data']

def get_next ( node ):
	"""
	Retrieve the contents of the next field .
	Pre - conditions : node : a node created by create ()
	Post - conditions : none
	Return:  the value stored previously in the next field
	"""
	return node ['next']

def set_data (node , val ):
	"""
	Set the contents of the data field to val.
	Pre - conditions : node : a node created by create (); val: a data value to be stored
	Post - conditions : stores the new data value , replacing the existing value
	Return none
	"""
	node ['data'] = val

def set_next (node , val ):
	"""
	Set the contents of the next field to val.
	Pre - conditions : node : a node created by create (); val: a node , or the value None
	Post - conditions : stores the new next value , replacing the existing value
	Return none
	"""
	node ['next'] = val

def insertOrd(node, data):
	"""
	Set the contents of the next field to new node containing data if node['data'] <= data and either
		node['next'] == None or node['next']['data'] > val['data'].
	Pre - conditions : node : a node created by create (); data: Any data value to be stored in the node
	Post - conditions : new node conatining data has been inserted maintaining ascending order of data
	Return: reference to the node just entered
	"""
	if (node == None):   ## no node exists yet
		newNode = create(data)
		return(newNode)
	if (data < node['data']):  # insert to the left of the current node
		newNode = create(data)
		newNode['next'] = node
		return(newNode)
	# insert further down the list
	node['next'] = insertOrd(node['next'],data)
	return(node)


def traverse(node):
	"""
	Output each node value in list.
	Pre - conditions : node : a node created by create ();
	Post - conditions : 
	Return: none
	"""
	iterator = node
	while (iterator != None):
		print("Value = ",iterator['data'])
		iterator = iterator['next']
	print("")


	