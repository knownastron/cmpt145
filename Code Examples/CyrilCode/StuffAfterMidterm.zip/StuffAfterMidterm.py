import SomeMoreStuff as stuff
 
x = 100
def trivial_function (x):
	#global x
	print ('Inside function x = ',x)
	x = x + 1
	print ('Inside function x = ',x)

trivial_function (x)
print('After function x = ',x)
 
'''
a = list ( range (10))
i = 0
print("List before loop: ",a)
print ("Length of list = ",len(a))
while i < len(a):  # what are we trying to do here?
	del a[i]
	i += 1
print("List after loop: ",a)

# use the iter function
stuff.useIter()
stuff.Testmonths()
stuff.iterTest()
print("Using city generator.....")
city = stuff.city_generator()
c = next(city)
while True:
		try:
			c = next(city)
			print(c)
		except StopIteration:
			break

print("Sum of 0..999 = ",stuff.sumOfDigits(999))
'''
'''
# division by zero
#print(stuff.divideAbyB(3,0))

try:
	print(stuff.divideAbyB(4,0))
except Exception as e:
	print(e)

print("Last statement of program.")
'''