import TStack as Stack
import TQueue as MyQueue

def check_brackets(input):
    """
    Purpose:
        Takes in a string, and determines if the bracket order and types match.
    Precondition:
        line: a string containing an expression. Ex: "(a+b)", "([{}()])"
    Post-condition:
        none
    Returns:
        True if the bracket order matched, False otherwise
    """
    # Strip out any characters that aren't the right type of brackets or spaces
    expression = ""
    valid_chars = "[](){}"
    for char in input:
        if char in valid_chars:
            expression += char

    # create the initial empty containers
    chars = MyQueue.create()
    brackets = Stack.create()
    unmatched_close = False

    # put all the characters in the Queue
    for c in expression:
        MyQueue.enqueue(chars, c)

    closed_brackets = ")]}"
    open_brackets = "([{"

    # brackets match if and only if every left bracket has a right bracket
    while not MyQueue.is_empty(chars) and not unmatched_close:
        char = MyQueue.dequeue(chars)
        # Check if the current character is a closing bracket
        if char in closed_brackets:
            # Get the index of the bracket we have
            char_index = closed_brackets.find(char)
            # If so, pop the stack, check what that is, see if it matches
            if Stack.is_empty(brackets):
                # Stack is empty, nothing to pop, more closed brackets than open brackets
                return False
            else:
                # If the popped character
                if Stack.pop(brackets) != open_brackets[char_index]:
                    return False
        # Only characters remaining should be open brackets since we stripped out any other characters
        else:
            Stack.push(brackets, char)

    # If the stack isn't empty, that means we had more open brackets than closed brackets
    return Stack.is_empty(brackets)


def print_valid_expression(expression):
    """
    Purpose:
        Takes in a string, and prints to the console whether it is a balanced expression
    Precondition:
        expression: string containing an expression. Ex: "(a+b)"
    Post-condition:
        none
    Returns:
        none, only prints to the console
    """
    # check how the analysis turned out
    result = check_brackets(expression)

    if result :
        print ('Balanced expression')
    else:
        print ('Not a balanced expression')