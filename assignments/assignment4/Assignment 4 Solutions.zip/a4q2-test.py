# CMPT 145: Linear ADTs
# Test the evaluator

import a4q2 as brackets

# dictionary of test case suite to feed into test driver loop
test_suite = [
    {"inputs": ['()','()()','(())'],
     "outputs": True,
     "reason": "Correct ( ) brackets"},
    {"inputs": ['[]','[][]','[[]]'],
     "outputs": True,
     "reason": "Correct [ ] brackets"},
    {"inputs": ['{}','{}{}','{{}}'],
     "outputs": True,
     "reason": "Correct { } brackets"},
    {"inputs": ['',' '],
     "outputs": True,
     "reason": "Testing no input"},
    {"inputs": ['([a+b] * [c-d])','(a*[b*{c}+(e/f)])'],
     "outputs": True,
     "reason": "Testing correct complex expression"},
    {"inputs": ['([a+b[ * [c-d])','{ [ ] } ( ] { ) ) {'],
     "outputs": False,
     "reason": "Testing incorrect complex expression"},
    {"inputs": [')(()','{]}['],
     "outputs": False,
     "reason": "Right number of brackets, wrong order"},
]

# Only testing the one function, do it thoroughly
for test_case in test_suite:
    inputs = test_case["inputs"]
    expected = test_case['outputs']
    reason = test_case['reason']

    # Multiple tests for each equivalence class
    for input in inputs:
        results = brackets.check_brackets(input)
        if results != expected:
            print('Test: Error', ' expected', expected,
                  ' but found ', results, '--', reason)

print('*** test complete ***')
