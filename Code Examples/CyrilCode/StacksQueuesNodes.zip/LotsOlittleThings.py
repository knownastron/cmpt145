
#import StackImplementation as Stack
import NodeImplementation as node
import Stack
import ModifiedQueue as Queue

# reverse a string using stack
def reverseString(inString):
	'''
	Purpose: demonstrate reversing a string using a stack
	Pre-condition: inString is a proper Python string
	Post-condition: none
	Return: a copy of inString reversed
	'''
	reverseStack = Stack.create()
	sLength = len(inString)
	for i in range(sLength):
		Stack.push(reverseStack,inString[i])
	newString = ""
	while not Stack.is_empty(reverseStack):
		newString += Stack.pop(reverseStack)
	return (newString)

def matchBrackets(inString):
	'''
	Purpose: demonstrate matching open and close parantheses in an algebraic expression
	Pre-condition: inString is a proper Python string representing an algebraic expression
	Post-condition: none
	Return: True if every '(' has a matching ')'; False otherwise
	'''
	# parse characters, push '(' onto stack, pop stack if ')' encountered; ignore everything else
	parenStack = Stack.create()
	sLength = len(inString)
	for i in range(sLength):
		if inString[i] == '(':
			Stack.push(parenStack,inString[i])
		elif inString[i] == ')':
			if Stack.is_empty(parenStack):
				return(False)   # mismatch on ')'
			Stack.pop(parenStack)  # don't need it
	if Stack.is_empty(parenStack):
		return(True)
	return (False)

def postFixCompute(inString):
	'''
	Purpose: demonstrate evaluating a postfix algebraic 
		expression of only single digit values
	Pre-condition: inString is a proper Python string representing a postfix algebraic expression
	Post-condition: none
	Return: numeric value represented by the expression; none otherwise
	'''
	evalStack = Stack.create()
	expList =inString.split()
	for i in expList:
		if i.isdigit():
			Stack.push(evalStack,int(i))
		else:
			#evaluate the operator
			rightarg = Stack.pop(evalStack)
			leftarg = Stack.pop(evalStack)
			# print("Evaluating: ",leftarg,i,rightarg)
			if (i == '+'):
				Stack.push(evalStack,leftarg+rightarg)
			elif (i == '-'):
				Stack.push(evalStack,leftarg-rightarg)
			elif (i == '*'):
				Stack.push(evalStack,leftarg*rightarg)
			elif (i == '/'):
				Stack.push(evalStack,leftarg/rightarg)
			elif (i == '^'):
				Stack.push(evalStack,leftarg**rightarg)
			elif (i == '%'):
				Stack.push(evalStack,leftarg%rightarg)

	return(Stack.pop(evalStack))

def precedenceOfOp(inOP):
	if inOP in ['+','-']: return (0)
	if inOP in ['*','/']: return (1)
	return (2)

def postFixFromInFix(inFixStr):
	'''
	Purpose: convert the infix arithmetic expression (with or without "()" to postfix
	Pre-condition: inString is a proper Python string representing an infix algebraic expression
	Post-condition: none
	Return: postfix equivalent arithmetic expression
	'''
	outStr = ""
	opStack = Stack.create()
	splitUp = inFixStr.split()
	#print (splitUp)
	for i in splitUp:
		if i == '(': 
			Stack.push(opStack,'(')
		elif i == ')':
			# pop everything into output until '(' popped
			operFromStack = Stack.pop(opStack)
			#print("Popped1: ",operFromStack)
			while (not (operFromStack == None or operFromStack == '(')):
				outStr += ' '+operFromStack
				#print("Test1: ",outStr)
				operFromStack = Stack.pop(opStack)
				#print("Popped2: ",operFromStack)
		elif i in ['+','-','*','/','^']:
			# determine precedence and then manipulate the stack
			doneOps = False
			while (not doneOps):
				if 	(Stack.is_empty(opStack)) or Stack.peek(opStack) == '(':
					Stack.push(opStack,i)
					doneOps = True
				else:
					finishedChk = False
					while not Stack.is_empty(opStack) and not finishedChk:
						if (precedenceOfOp(i) <= precedenceOfOp(Stack.peek(opStack))):
							operFromStack = Stack.pop(opStack)
							#print("Popped3: ",operFromStack)
							outStr = outStr + ' ' + operFromStack
						else:
							finishedChk = True
					Stack.push(opStack,i)
					doneOps = True
		else:
			# operand to output (may be multiple length string)
			outStr += ' '+i
	# copy rest of stack to output
	while (not Stack.is_empty(opStack)):
		operFromStack = Stack.pop(opStack)
		#print("Popped4: ",operFromStack)

		outStr = outStr + ' ' + operFromStack

	return (outStr)

def IreturnaTuple():
	return 5,3
'''
#test reverse string
theString = "Hello World"
print(theString, " in reverse = ",reverseString(theString))
'''
'''
# Match brackets in an arithmetic string
theString = "((3+4)*8+(4-5))"   # this should come back true
print(theString," has matching brackets ", matchBrackets(theString))
theString = "((3+4)*8+((4-5))"   # this should come back false: one too many open
print(theString," has matching brackets ", matchBrackets(theString))
theString = "((3+4))*8+(4-5))"   # this should come back false: one too many close
print(theString," has matching brackets ", matchBrackets(theString))
theString = "3+4*8+4-5"   # this should come back true: no brackets at all
print(theString," has matching brackets ", matchBrackets(theString))
'''
'''
#evaluating postfix
theString = "3 4 + 55 16 - *"
print(theString," has value ", postFixCompute(theString))
theString = "3 4 + 3 * 4 6 + /"
print(theString," has value ", postFixCompute(theString))
theString = "3 2 % 2 6 - 3 2 ^ / +"
print(theString," has value ", postFixCompute(theString))
'''
'''
# infix to postfix
infixExpression = '( 3 + 2 ) * 7 - 27 / ( 3 * 9 )'
postFixEXpression = postFixFromInFix(infixExpression)
print(infixExpression)
print("Evaluates to: ",postFixCompute(postFixEXpression))
print(postFixCompute(postFixFromInFix('( 3 + 4 ) * 5')))
'''

aQ = Queue.create()
for aLetter in "Hello":
	Queue.enqueue(aQ,aLetter)
while not Queue.is_empty(aQ):
	print(Queue.dequeue(aQ))

'''
x = node . create (5, None )
y = node . create (1, x)
z = node . create (8, y)
print ( node . get_data (x))
print ( node . get_data ( node . get_next (z )))
print ( node . get_data ( node . get_next ( node . get_next (z ))))
'''
'''
# create a chain of 3-->2-->1-->5-->4
chain = node.create(4,None)
chain = node.create(5,chain)
chain = node.create(1,chain)
chain = node.create(2,chain)
chain = node.create(3,chain)
tmpChain = chain
print("Original chain:")
while not tmpChain == None:
	print(node.get_data(tmpChain))
	tmpChain = node.get_next(tmpChain)

# remove 3 from the chain
tmp = node.get_next(chain)
node.set_next(chain,None)
chain = tmp
tmpChain = chain
print("Chain after remove 3:")
while not tmpChain == None:
	print(node.get_data(tmpChain))
	tmpChain = node.get_next(tmpChain)
# add 6 at the beginning
chain = node.create(6,chain)
tmpChain = chain
print("Chain after add 6 at the beginning:")
while not tmpChain == None:
	print(node.get_data(tmpChain))
	tmpChain = node.get_next(tmpChain)

# add 7 at end of sequence
tmpChain = chain
while not node.get_next(tmpChain) == None:
	tmpChain = node.get_next(tmpChain)
node.set_next(tmpChain,node.create(7))
tmpChain = chain
print("Chain after add 7 at the end:")
while not tmpChain == None:
	print(node.get_data(tmpChain))
	tmpChain = node.get_next(tmpChain)
'''
x,y = IreturnaTuple()
z = IreturnaTuple()
print(x,y,z)
a = z
print (a == z, a is z)
z = (y,x)
print(x,y,z,a)
print (a == z, a is z)
