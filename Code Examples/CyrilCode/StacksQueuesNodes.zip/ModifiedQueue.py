import StackImplementation as Stack


# implement a queue using the stack
def create ():
	"""
	Purpose: creates an empty queue
	Pre-conditions: none
	Post-conditions: none
	Return: an empty queue
	"""
	queue = {}
	queue["enqueue"] = Stack.create()
	queue["dequeue"] = Stack.create()
	return queue

def is_empty ( queue ):
	"""
	Purpose: checks if the given queue has no data in it
	Pre - conditions : queue is a queue created by create ()
	Post-conditions: none
	Return : True if the queue has no data , or false otherwise
	"""
	return (Stack.is_empty(queue["enqueue"])) and (Stack.is_empty(queue["dequeue"]))

def size ( queue ):
	"""
	Purpose: returns the number of data values in the given queue
	Pre - conditions : queue : a queue created by create ()
	Post-conditions: none
	Return : The number of data values in the queue
	"""
	return Stack.size(queue["enqueue"]) + Stack.size(queue["dequeue"])

def enqueue( queue,element ):
	"""
	Purpose: adds the given element to the back of the queue
	Pre - conditions : queue : a queue created by create ()
	Post-conditions: the queue now contains the element and size has increased
	Return : none
	"""
	# check if dequeue is not empty. If not pop everything and push onto enqueue
	while not (Stack.is_empty(queue["dequeue"])):
		Stack.push(queue["enqueue"],Stack.pop(queue["dequeue"]))
	# now push onto enqueue
	Stack.push(queue["enqueue"],element)

def dequeue( queue ):
	"""
	Purpose: removes the first element from front of the queue
	Pre - conditions : queue : a queue created by create ()
	Post-conditions: the queue no longer contains the element and size has decreased
	Return : the element at the front of the queue if one exists; none otherwise
	"""
	# check if dequeue is not empty. If not pop and return element
	if not (Stack.is_empty(queue["dequeue"])):
		return (Stack.pop(queue["dequeue"]))
	# check if enqueue is empty; if YES return none
	if (Stack.is_empty(queue["enqueue"])):
		return (None)
	# pop all enqueue elements onto dequeue then pop and return top dequeue element
	while not (Stack.is_empty(queue["enqueue"])):
		Stack.push(queue["dequeue"],Stack.pop(queue["enqueue"]))
	return (Stack.pop(queue["dequeue"]))

def peek(queue):
	"""
	Purpose: returns the value of the first element from front of the queue without removing it from the queue
	Pre - conditions : queue : a queue created by create ()
	Post-conditions: none
	Return : value of the element at the front of the queue if one exists; none otherwise
	"""
	frontOfQueue = dequeue(queue)
	if not frontOfQueue == None:
		Stack.push(queue["dequeue"],frontOfQueue) # push back onto the stack it came from
	return(frontOfQueue)