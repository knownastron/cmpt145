"""
Purpose: A stack is a very usefull ADT. This implementation can be used in many different applications
Author: Mike Horsch/Cyril Coupal
"""

import NodeImplementation as node

def create ():
	"""
	Purpose: creates an empty stack
	Pre-conditions: none
	Post-conditions: none
	Return: an empty stack
	"""
	stack = {}
	stack ["size"] = 0 # how many elements in the stack
	stack ['top'] = None # the node chain starts here
	return stack

def is_empty ( stack ):
	"""
	Purpose: checks if the given queue has no data in it
	Pre - conditions : queue is a queue created by create ()
	Post-conditions: none
	Return : True if the queue has no data , or false otherwise
	"""
	return stack ['size'] == 0

def size ( stack ):
	"""
	Purpose: returns the number of data values in the given queue
	Pre - conditions : queue : a queue created by create ()
	Post-conditions: none
	Return : The number of data values in the queue
	"""
	return stack ['size']

def push (stack , value ):
	"""
	Purpose: adds the given data value to the given stack
	Pre - conditions : stack : a stack created by create () value : data to be added
	Post - condition : 	the value is added to the stack
	Return : ( none )
	"""
	new_node = node . create (value , stack ['top'])
	stack ['top'] = new_node
	stack ['size'] += 1

def pop ( stack ):
	"""
	Purpose: removes and returns a data value from the given stack
	Pre - conditions : stack : a stack created by create ()
	Post - condition : the first value is removed from the stack
	Return : the top value in the stack , or None
	"""
	if is_empty ( stack ):
		return None
	prev_first_node = stack ['top']
	result = node . get_data ( prev_first_node )
	stack ['top'] = node . get_next ( prev_first_node )
	stack ['size'] -= 1
	return result

def peek(stack):
	if is_empty(stack):
		return (None)
	stackTop = stack['top']
	return stackTop['data']


