def useIter():
	aList = [2,3,4,5,"Hello",12.3,"Cyril"]
	x = iter(aList)
	for i in range(len(aList)):
		print(next(x))

def Testmonths():
	names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul","Aug","Sept","Oct","Nov","Dec"]
	values = [i for i in range (1,13)]
	for name, value in zip(names, values):
		print (name, value)

def iterTest():
	other_cities = ["Strasbourg", "Freiburg", "Stuttgart", 
                "Vienna / Wien", "Hannover", "Berlin", 
                "Zurich"]
	city_iterator = iter(other_cities)
	while city_iterator:
		try:
			city = next(city_iterator)
			print(city)
		except StopIteration:
			break

def city_generator():
    yield("London")
    yield("Hamburg")
    yield("Konstanz")
    yield("Amsterdam")
    yield("Berlin")
    yield("Zurich")
    yield("Schaffhausen")
    yield("Stuttgart")

def sumOfDigits(n):
	totalsum = 0
	for i in range (n+1):
		totalsum += i
	return(totalsum)

def divideAbyB(a,b):
	assert b == 0
		#raise Exception("You must not supply a 0 for b.") # why raise exception? Don't what to return in this case
	
	return(a/b)